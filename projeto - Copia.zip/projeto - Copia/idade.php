<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="pt-br">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Idade</title>
</head>
<body>
    <form action="idade.php" method="post">
            <label for="idade">idade </label><br>
            <input type="number" name="idade" id="idade" required class="formu">
<?php 
$calIda = $_POST['idade'];
$ano = date("Y");
$calIda = $ano - $calIda;


?>
<p><?php echo $calIda; ?></p>




</body>
</html>