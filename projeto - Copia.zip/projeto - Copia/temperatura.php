<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>temperatura</title>
</head>
<body>
<form action="temperatura.php" method="post">
            <label for="celcius">graus </label><br>
            <input type="number" name="celcius" id="celcius" required class="formu"> <br>
<?php
$cal = $_POST['celcius'];

$cal = ($cal * 9) / 5 + 32;



?>    
 <p><?php echo $cal; ?></p>
 

</body>
</html>